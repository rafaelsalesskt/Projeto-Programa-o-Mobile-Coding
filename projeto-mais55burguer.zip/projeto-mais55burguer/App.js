import React, { useState } from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  Image, 
  TouchableOpacity, 
  ScrollView, 
  FlatList, 
  TextInput,
  SafeAreaView,
  Alert
} from 'react-native';

const MENU_ITEMS = [
  {
    id: '1',
    nome: 'Brazuca Burger',
    preco: 32.90,
    ingredientes: 'Pão brioche, blend artesanal de 150g, muito queijo prato, maionese de couve e farofa de bacon.',
    imagem: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500'
  },
  {
    id: '2',
    nome: 'Nordestino',
    preco: 38.90,
    ingredientes: 'Pão australiano, carne de sol de 150g, queijo coalho tostado, manteiga de garrafa e melado de cana.',
    imagem: 'https://images.unsplash.com/photo-1553979459-d2229ba7433b?w=500'
  },
  {
    id: '3',
    nome: 'Sampa Smash',
    preco: 26.00,
    ingredientes: 'Pão prensado, dois blends smash de 70g, cheddar duplo fatiado, cebola roxa e picles da casa.',
    imagem: 'https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?w=500'
  },
  {
    id: '4',
    nome: 'X-Tudo +55',
    preco: 45.00,
    ingredientes: 'Pão de hambúrguer, blend 150g, ovo frito, presunto, queijo, alface, tomate, milho e batata palha.',
    imagem: 'https://images.unsplash.com/photo-1525059696034-4967a8e1dca2?w=500'
  }
];

export default function App() {

  const [telaAtual, setTelaAtual] = useState('Login');
  const [itemSelecionado, setItemSelecionado] = useState(null);
  const [carrinho, setCarrinho] = useState([]);

 
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  
  const lidarComLogin = () => {
    if (email.trim() === '' || senha.trim() === '') {
      alert('Por favor, preencha todos os campos!');
      return;
    }
   
    setTelaAtual('Menu');
  };

 
  const adicionarAoCarrinho = (item) => {
    setCarrinho([...carrinho, item]);
    setTelaAtual('Cart');
  };

  const calcularTotal = () => {
    return carrinho.reduce((total, item) => total + item.preco, 0).toFixed(2);
  };

  const finalizarPedido = () => {
    setCarrinho([]);
    setTelaAtual('Success');
  };

 
  const TelaLogin = () => (
    <View style={styles.containerCenter}>
      <View style={styles.logoContainer}>
        <Text style={styles.logoPrefixo}>+</Text>
        <Text style={styles.logoNumero}>55</Text>
        <Text style={styles.logoSufixo}>BURGER</Text>
      </View>
      
      <Text style={styles.subtituloHome}>Faça seu login para pedir</Text>

      <View style={styles.areaFormulario}>
        <TextInput 
          style={styles.input}
          placeholder="E-mail"
          placeholderTextColor="#777"
          keyboardType="email-address"
          autoCapitalize="none"
          value={email}
          onChangeText={setEmail}
        />
        
        <TextInput 
          style={styles.input}
          placeholder="Senha"
          placeholderTextColor="#777"
          secureTextEntry={true}
          value={senha}
          onChangeText={setSenha}
        />

        <TouchableOpacity style={styles.botaoPrincipal} onPress={lidarComLogin}>
          <Text style={styles.textBotao}>Entrar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  // --- TELA 2: CARDÁPIO (MENU) ---
  const TelaMenu = () => (
    <SafeAreaView style={styles.container}>
      <View style={styles.headerMenu}>
        <Text style={styles.headerTitulo}>Cardápio +55</Text>
        <TouchableOpacity style={styles.botaoSair} onPress={() => setTelaAtual('Login')}>
          <Text style={styles.textBotaoSair}>Sair</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={MENU_ITEMS}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingBottom: 20 }}
        renderItem={({ item }) => (
          <TouchableOpacity 
            style={styles.cardProduto} 
            onPress={() => { setItemSelecionado(item); setTelaAtual('Details'); }}
          >
            <Image source={{ uri: item.imagem }} style={styles.imgCard} />
            <View style={styles.infoCard}>
              <Text style={styles.nomeProduto}>{item.nome}</Text>
              <Text style={styles.precoProduto}>R$ {item.preco.toFixed(2)}</Text>
            </View>
          </TouchableOpacity>
        )}
      />
    </SafeAreaView>
  );

  // --- TELA 3: DETALHES ---
  const TelaDetalhes = () => (
    <ScrollView style={styles.container}>
      <Image source={{ uri: itemSelecionado?.imagem }} style={styles.imgDetalhe} />
      <View style={styles.conteudoDetalhe}>
        <Text style={styles.tituloDetalhe}>{itemSelecionado?.nome}</Text>
        <Text style={styles.precoDetalhe}>R$ {itemSelecionado?.preco.toFixed(2)}</Text>
        
        <Text style={styles.subtituloSecao}>Ingredientes</Text>
        <Text style={styles.descricaoDetalhe}>{itemSelecionado?.ingredientes}</Text>
        
        <TouchableOpacity 
          style={styles.botaoPrincipal} 
          onPress={() => adicionarAoCarrinho(itemSelecionado)}
        >
          <Text style={styles.textBotao}>Adicionar ao Carrinho</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.botaoSecundario} onPress={() => setTelaAtual('Menu')}>
          <Text style={styles.textBotaoSecundario}>Voltar ao Cardápio</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );

  // --- TELA 4: CARRINHO ---
  const TelaCarrinho = () => (
    <SafeAreaView style={styles.container}>
      <Text style={styles.headerTitulo}>Seu Carrinho</Text>
      {carrinho.length === 0 ? (
        <View style={styles.containerCenter}>
          <Text style={styles.txtVazio}>Nenhum item por aqui ainda... 🛍️</Text>
          <TouchableOpacity style={styles.botaoPrincipal} onPress={() => setTelaAtual('Menu')}>
            <Text style={styles.textBotao}>Bora escolher um burger!</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <>
          <ScrollView style={{ flex: 1, paddingHorizontal: 20 }}>
            {carrinho.map((item, index) => (
              <View key={index} style={styles.itemCarrinho}>
                <Text style={styles.nomeItemCarrinho}>{item.nome}</Text>
                <Text style={styles.precoItemCarrinho}>R$ {item.preco.toFixed(2)}</Text>
              </View>
            ))}
            <View style={styles.linhaTotal}>
              <Text style={styles.txtTotal}>Total</Text>
              <Text style={styles.txtPrecoTotal}>R$ {calcularTotal()}</Text>
            </View>
          </ScrollView>
          
          <View style={{ padding: 20 }}>
            <TouchableOpacity style={styles.botaoPrincipal} onPress={finalizarPedido}>
              <Text style={styles.textBotao}>Finalizar e Enviar</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.botaoSecundario} onPress={() => setTelaAtual('Menu')}>
              <Text style={styles.textBotaoSecundario}>Adicionar mais itens</Text>
            </TouchableOpacity>
          </View>
        </>
      )}
    </SafeAreaView>
  );

  // --- TELA 5: CONFIRMAÇÃO (SUCCESS) ---
  const TelaSucesso = () => (
    <View style={styles.containerCenter}>
      <View style={styles.iconeSucessoContainer}>
        <Text style={styles.iconeSucesso}>🔥</Text>
      </View>
      <Text style={styles.tituloSucesso}>Pedido Confirmado!</Text>
      <Text style={styles.subtituloHome}>A chapa do +55 Burger já está quente e preparando sua janta.</Text>
      <Text style={styles.tempoEntrega}>Previsão: 25 a 40 minutos</Text>
      
      <TouchableOpacity style={styles.botaoPrincipal} onPress={() => setTelaAtual('Menu')}>
        <Text style={styles.textBotao}>Fazer Novo Pedido</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: '#141414' }}>
      {telaAtual === 'Login' && <TelaLogin />}
      {telaAtual === 'Menu' && <TelaMenu />}
      {telaAtual === 'Details' && <TelaDetalhes />}
      {telaAtual === 'Cart' && <TelaCarrinho />}
      {telaAtual === 'Success' && <TelaSucesso />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#141414',
    paddingTop: 40,
  },
  containerCenter: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#141414',
    padding: 24,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 10,
  },
  logoPrefixo: {
    fontSize: 36,
    color: '#FFB800',
    fontWeight: '900',
    lineHeight: 36,
  },
  logoNumero: {
    fontSize: 80,
    color: '#FFF',
    fontWeight: 'bold',
    lineHeight: 80,
  },
  logoSufixo: {
    fontSize: 18,
    color: '#FFB800',
    fontWeight: '800',
    letterSpacing: 4,
  },
  subtituloHome: {
    fontSize: 15,
    color: '#A0A0A0',
    textAlign: 'center',
    marginBottom: 30,
    paddingHorizontal: 20,
  },
  areaFormulario: {
    width: '100%',
    maxWidth: 320,
  },
  input: {
    backgroundColor: '#1E1E1E',
    color: '#FFF',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderRadius: 12,
    fontSize: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#2A2A2A',
  },
  headerMenu: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
    marginVertical: 20,
  },
  headerTitulo: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFF',
  },
  botaoSair: {
    position: 'absolute',
    right: 20,
    padding: 8,
  },
  textBotaoSair: {
    color: '#FF4D4D',
    fontWeight: '600',
  },
  botaoPrincipal: {
    backgroundColor: '#FFB800',
    paddingVertical: 16,
    borderRadius: 12,
    width: '100%',
    alignItems: 'center',
    marginVertical: 8,
  },
  textBotao: {
    color: '#141414',
    fontSize: 18,
    fontWeight: 'bold',
  },
  botaoSecundario: {
    paddingVertical: 14,
    alignItems: 'center',
  },
  textBotaoSecundario: {
    color: '#FFB800',
    fontSize: 16,
    fontWeight: '600',
  },
  cardProduto: {
    flexDirection: 'row',
    backgroundColor: '#1E1E1E',
    marginHorizontal: 20,
    marginVertical: 10,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#2A2A2A',
  },
  imgCard: {
    width: 110,
    height: 110,
  },
  infoCard: {
    flex: 1,
    padding: 16,
    justifyContent: 'center',
  },
  nomeProduto: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFF',
  },
  precoProduto: {
    fontSize: 16,
    color: '#FFB800',
    fontWeight: 'bold',
    marginTop: 6,
  },
  imgDetalhe: {
    width: '100%',
    height: 280,
  },
  conteudoDetalhe: {
    padding: 24,
  },
  tituloDetalhe: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFF',
  },
  precoDetalhe: {
    fontSize: 24,
    color: '#FFB800',
    fontWeight: 'bold',
    marginVertical: 12,
  },
  subtituloSecao: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#A0A0A0',
    textTransform: 'uppercase',
    marginTop: 16,
    marginBottom: 8,
    letterSpacing: 1,
  },
  descricaoDetalhe: {
    fontSize: 16,
    color: '#DDD',
    lineHeight: 24,
    marginBottom: 32,
  },
  itemCarrinho: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#1E1E1E',
    padding: 18,
    borderRadius: 12,
    marginBottom: 12,
  },
  nomeItemCarrinho: {
    fontSize: 16,
    color: '#FFF',
    fontWeight: '500',
  },
  precoItemCarrinho: {
    fontSize: 16,
    color: '#FFB800',
    fontWeight: 'bold',
  },
  linhaTotal: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderTopColor: '#2A2A2A',
    marginTop: 24,
    paddingTop: 16,
  },
  txtTotal: {
    fontSize: 18,
    color: '#A0A0A0',
  },
  txtPrecoTotal: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFB800',
  },
  txtVazio: {
    fontSize: 16,
    color: '#A0A0A0',
    marginBottom: 24,
  },
  iconeSucessoContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#2A2A2A',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  iconeSucesso: {
    fontSize: 48,
  },
  tituloSucesso: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#FFF',
    marginBottom: 12,
  },
  tempoEntrega: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFB800',
    marginTop: 8,
    marginBottom: 40,
  }
});